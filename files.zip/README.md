# 🎂 Zaidi Bakery — Full Stack Web Application

## Tech Stack
- **Frontend**: HTML5, CSS3, Vanilla JavaScript (Single Page Application)
- **Backend**: PHP 8.0+ (REST API)
- **Database**: Microsoft SQL Server 2014
- **Auth**: JWT (JSON Web Tokens) + bcrypt password hashing
- **Images**: Unsplash CDN (real product photography)

---

## 📁 Project Structure

```
zaidi_bakery/
├── index.html                   ← Main frontend (SPA)
├── .htaccess                    ← Apache URL rewriting
├── php/
│   ├── index.php                ← API Front Controller / Router
│   ├── config/
│   │   ├── database.php         ← SQL Server PDO connection
│   │   └── config.php           ← App config, helpers, JWT utils
│   └── controllers/
│       ├── AuthController.php   ← Register, Login, Me
│       ├── ProductController.php← CRUD products + reviews
│       ├── OrderController.php  ← Place order, track, update
│       └── AdminController.php  ← Dashboard, reports, employees
└── sql/
    └── zaidi_bakery_database.sql← Complete MS SQL Server 2014 schema
```

---

## ⚙️ Setup Instructions

### 1. Database Setup (MS SQL Server 2014)

Open **SQL Server Management Studio (SSMS)** and run:
```sql
-- Run the full schema file
zaidi_bakery/sql/zaidi_bakery_database.sql
```

This creates:
- All 9 tables (Customers, Employees, Products, Categories, Orders, Order_Items, Payments, Coupons, Notifications)
- All views (vw_DashboardStats, vw_ProductsWithRating, vw_OrderDetails)
- Stored procedures (sp_PlaceOrder, sp_UpdateOrderStatus, sp_SalesReport)
- Sample data (12 products, 6 categories, 2 employees, 2 customers)

### 2. Configure Database Connection

Edit `php/config/database.php`:
```php
define('DB_SERVER',   'localhost');     // Your SQL Server host/IP
define('DB_NAME',     'zaidi_bakery');
define('DB_USER',     'sa');            // Your SQL login
define('DB_PASSWORD', 'YourPassword!');
```

### 3. Web Server (XAMPP/WAMP/Apache)

1. Copy the entire `zaidi_bakery/` folder to `htdocs/` (XAMPP) or `www/` (WAMP)
2. Install PHP SQL Server driver: **php_sqlsrv** and **php_pdo_sqlsrv**
   - Download from: https://github.com/microsoft/msphpsql/releases
   - Add to `php.ini`:
     ```
     extension=php_sqlsrv_82_nts.dll
     extension=php_pdo_sqlsrv_82_nts.dll
     ```
3. Enable `mod_rewrite` in Apache
4. Visit: `http://localhost/zaidi_bakery/`

### 4. API Base URL

In `index.html`, update the API constant:
```javascript
const API = '/zaidi_bakery/api'; // Adjust to match your path
```

---

## 🔐 Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@zaidibakery.pk | Admin@1234 |
| Delivery | delivery@zaidibakery.pk | Delivery@1234 |
| Customer | Register via the website | - |

> ⚠️ Change passwords after first login!

---

## 🌐 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new customer |
| POST | `/api/auth/login` | Login (customer/admin/delivery) |
| GET  | `/api/auth/me` | Get current user info |

### Products
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/products` | List all products (with filters) |
| GET  | `/api/products/{id}` | Get single product |
| POST | `/api/products` | Create product [admin] |
| PUT  | `/api/products/{id}` | Update product [admin] |
| DELETE | `/api/products/{id}` | Delete product [admin] |
| GET  | `/api/products/{id}/reviews` | Get product reviews |
| POST | `/api/products/{id}/reviews` | Submit review [customer] |

### Orders
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/orders` | List orders (role-filtered) |
| POST | `/api/orders` | Place new order [customer] |
| GET  | `/api/orders/{id}` | Get order detail |
| PUT  | `/api/orders/{id}/status` | Update status [admin/delivery] |
| GET  | `/api/orders/delivery` | Delivery assignments [delivery] |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/dashboard` | Stats overview |
| GET | `/api/admin/reports?period=daily` | Sales reports |
| GET | `/api/admin/employees` | List employees |
| POST | `/api/admin/employees` | Add employee |
| PUT | `/api/admin/employees/{id}` | Update employee |
| DELETE | `/api/admin/employees/{id}` | Remove employee |
| GET | `/api/admin/customers` | List customers |
| GET | `/api/admin/payments` | List payments |
| GET | `/api/admin/low-stock` | Low stock alert |

---

## 🗄️ Database Tables

| Table | Description |
|-------|-------------|
| `Roles` | User roles (customer, admin, delivery) |
| `Customers` | Customer accounts with hashed passwords |
| `Employees` | Admin & delivery staff |
| `Categories` | Product categories (6 types) |
| `Products` | Full product catalog with stock |
| `Orders` | Order records with status tracking |
| `Order_Items` | Line items per order |
| `Payments` | Payment records (card, JazzCash, EasyPaisa, COD) |
| `Coupons` | Discount coupons system |
| `Notifications` | In-app notifications per customer |
| `Product_Ratings` | Customer reviews & ratings |

---

## 🎨 Features

### Customer
- ✅ Register / Login with JWT authentication
- ✅ Browse all products with real Unsplash images
- ✅ Filter by category, sort by price/rating
- ✅ Add to cart with qty controls
- ✅ Wishlist functionality
- ✅ Checkout with delivery/pickup options
- ✅ Multiple payment methods (JazzCash, EasyPaisa, Card, COD)
- ✅ Coupon code support
- ✅ Order tracking
- ✅ Product reviews (after purchase)

### Admin
- ✅ Dashboard with live stats (revenue, orders, customers)
- ✅ Weekly sales bar chart
- ✅ Recent orders table with status badges
- ✅ Low stock alerts
- ✅ Full CRUD for products
- ✅ Employee management (add, edit, deactivate)
- ✅ Customer management
- ✅ Payment records view
- ✅ Daily/Weekly/Monthly sales reports

### Delivery Staff
- ✅ View assigned delivery orders
- ✅ Mark orders as delivered
- ✅ Real-time status updates

---

## 🔒 Security

- Passwords hashed with **bcrypt** (cost factor 10)
- **JWT authentication** with 24-hour expiry
- Role-based access control on every endpoint
- SQL injection prevention via **PDO prepared statements**
- Input sanitization on all user inputs
- HTTPS enforced via `.htaccess` headers

---

## 📞 Support
**Zaidi Bakery** — F-7/2, Islamabad | hello@zaidibakery.pk | +92 51 123 4567
